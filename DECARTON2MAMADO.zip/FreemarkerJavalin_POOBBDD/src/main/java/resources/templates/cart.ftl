<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Carrito de Compra</title>
    <link rel="stylesheet" href="/static/css/home.css">
</head>
<body>
<div class="container">
    <!-- Botón de cerrar sesión -->
    <div class="logout-container">
        <a href="/logout" class="logout-button">Cerrar Sesión</a>
    </div>

    <h1>Carrito de Compra</h1>

    <!-- Lista de productos en el carrito -->
    <#if cart?size == 0>
    <p>No hay productos en el carrito.</p>
    <#else>
    <table id="cart-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Precio (€)</th>
                <th>Cantidad</th>
            </tr>
        </thead>
        <tbody>
            <#list cart as item>
            <tr>
                <!-- ID del producto -->
                <td>${item.idcompra!}</td>
                <!-- Nombre del producto -->
                <td>${item.nombreProducto!}</td>
                <!-- Descripción del producto -->
                <td>${item.descripccion!}</td>
                <!-- Precio del producto -->
                <td>${item.precio!"N/A"}€</td>
                <!-- Cantidad del producto -->
                <td>${item.cantidad!"0"}</td>
            </tr>
            </#list>
        </tbody>
    </table>

    <!-- Botón para comprar -->
    <form action="/checkout" method="post" style="margin-top: 20px;">
        <button type="submit" class="checkout-button">Comprar Ahora</button>
    </form>
    </#if>

    <!-- Botón para volver a la página principal -->
    <a href="/home" class="back-button">Volver al Inicio</a>
</div>
</body>
</html>