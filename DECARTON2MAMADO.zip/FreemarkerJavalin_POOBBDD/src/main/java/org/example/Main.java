package org.example;

import io.javalin.Javalin;
import io.javalin.rendering.template.JavalinFreemarker;
import freemarker.template.Configuration;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.example.dao.ProductDAO;
import org.example.dao.UserDAO;
import org.example.entity.User;

public class Main {
    public static void main(String[] args) {
        // Configurar FreeMarker
        Configuration freemarkerConfig = new Configuration(Configuration.VERSION_2_3_32);
        freemarkerConfig.setClassForTemplateLoading(Main.class, "/templates");

        // Inicializar Javalin con FreeMarker y archivos estáticos
        Javalin app = Javalin.create(config -> {
            config.fileRenderer(new JavalinFreemarker(freemarkerConfig));
            config.staticFiles.add(staticFiles -> {
                staticFiles.directory = "/static"; // Carpeta "static" dentro de resources
                staticFiles.hostedPath = "/static"; // Ruta base en el navegador
            });
        }).start(8080);

        // Instanciar DAO
        UserDAO userDAO = new UserDAO();

        // Rutas
        app.get("/", ctx -> ctx.redirect("/login")); // Redirigir al login por defecto

        app.get("/logout", ctx -> {
            ctx.sessionAttribute("username", null); // Limpiar la sesión
            ctx.sessionAttribute("isAdmin", null);
            ctx.redirect("/login");
        });

        // Ruta para mostrar el formulario de registro (GET)
        app.get("/register", ctx -> {
            Map<String, Object> model = new HashMap<>();
            model.put("error", ctx.sessionAttribute("error"));
            ctx.sessionAttribute("error", null); // Limpiar el mensaje de error
            ctx.render("register.ftl", model);
        });

        app.get("/home", ctx -> {
            List<Map<String, Object>> products = ProductDAO.getAllProducts(); // Obtener todos los productos
            Map<String, Object> model = new HashMap<>();
            model.put("productos", products); // Pasar los productos al modelo
            ctx.render("home.ftl", model); // Renderizar la plantilla con los productos
        });

        // Ruta para procesar el formulario de registro (POST)
        app.post("/register", ctx -> {
            String username = ctx.formParam("username");
            String password = ctx.formParam("password");

            // Validar que el nombre de usuario no exista ya
            if (!userDAO.isUsernameAvailable(username)) {
                ctx.sessionAttribute("error", "El nombre de usuario ya está en uso");
                ctx.redirect("/register");
                return;
            }

            // Crear un nuevo usuario
            User newUser = new User();
            newUser.setUsername(username);
            newUser.setPassword(password);

            // Guardar el usuario en la base de datos usando el DAO
            userDAO.save(newUser);

            // Redirigir al login con mensaje de éxito
            Map<String, Object> model = new HashMap<>();
            model.put("success", "Registro exitoso. Por favor, inicia sesión.");
            ctx.render("login.ftl", model);
        });

        // Ruta para mostrar la página de inicio de sesión
        app.get("/login", ctx -> {
            Map<String, Object> model = new HashMap<>();
            model.put("error", ctx.sessionAttribute("error")); // Mostrar mensaje de error si existe
            ctx.sessionAttribute("error", null); // Limpiar el mensaje de error
            ctx.render("login.ftl", model);
        });

        // Ruta para procesar el inicio de sesión
        app.post("/login", ctx -> {
            String username = ctx.formParam("username");
            String password = ctx.formParam("password");

            User user = userDAO.findByUsername(username); // Buscar el usuario por nombre de usuario
            if (user != null && user.getPassword().equals(password)) {
                ctx.sessionAttribute("username", username);
                ctx.redirect("/home");
            } else {
                ctx.sessionAttribute("error", "Credenciales incorrectas");
                ctx.redirect("/login");
            }
        });
    }
}