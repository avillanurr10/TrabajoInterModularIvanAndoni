package org.example.dao;

import org.example.entity.Product;
import org.example.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductDAO {

    // Método para obtener todos los productos
    public static List<Map<String, Object>> getAllProducts() {
        List<Map<String, Object>> products = new ArrayList<>();
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM Product"; // Consulta HQL para obtener todos los productos
            List<Product> productList = session.createQuery(hql, Product.class).list();

            for (Product product : productList) {
                Map<String, Object> productMap = new HashMap<>();
                productMap.put("id", product.getId());
                productMap.put("nombre", product.getNombre());
                productMap.put("descripccion", product.getDescripccion());
                productMap.put("precio", product.getPrecio());
                productMap.put("stock", product.getStock());
                products.add(productMap);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return products;
    }

    // Método para eliminar un producto por ID
    public void deleteProduct(int productId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Product product = session.get(Product.class, productId);
            if (product != null) {
                session.delete(product);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}