package org.example.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "carrito")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idcompra;

    @Column(nullable = false)
    private String nombreProducto;

    @Column(nullable = false)
    private String descripccion;

    @Column(nullable = false)
    private double precio;

    @Column(nullable = false)
    private int cantidad;

    @ManyToOne
    @JoinColumn(name = "idUsuario", nullable = false)
    private User user;

    // Getters y Setters
    public int getIdcompra() { return idcompra; }
    public void setIdcompra(int idcompra) { this.idcompra = idcompra; }

    public String getNombreProducto() { return nombreProducto; }
    public void setNombreProducto(String nombreProducto) { this.nombreProducto = nombreProducto; }

    public String getDescripccion() { return descripccion; }
    public void setDescripccion(String descripccion) { this.descripccion = descripccion; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}