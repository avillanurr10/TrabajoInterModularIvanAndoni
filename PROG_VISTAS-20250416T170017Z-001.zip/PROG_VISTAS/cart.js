document.addEventListener('DOMContentLoaded', function() {
    const logo = document.querySelector('.logo');
    
    logo.addEventListener('mouseenter', () => {
        logo.style.transform = 'scale(1.08) rotate(2deg)';
    });

    logo.addEventListener('mouseleave', () => {
        logo.style.transform = 'scale(1) rotate(0)';
    });

    logo.addEventListener('click', () => {
        logo.style.transform = 'scale(0.95)';
        setTimeout(() => {
            logo.style.transform = 'scale(1.05)';
        }, 150);
    });

    const checkoutButton = document.querySelector('.checkout-button');
    if (checkoutButton) {
        checkoutButton.addEventListener('click', () => {
            checkoutButton.innerHTML = '<span class="loader"></span> Procesando...';
            checkoutButton.disabled = true;
        });

        const loaderStyle = `
            <style>
                .loader {
                    display: inline-block;
                    width: 18px;
                    height: 18px;
                    border: 3px solid rgba(255,255,255,0.3);
                    border-radius: 50%;
                    border-top-color: #fff;
                    animation: spin 1s infinite linear;
                    vertical-align: middle;
                    margin-right: 8px;
                }
                @keyframes spin {
                    to { transform: rotate(360deg); }
                }
            </style>
        `;
        document.head.insertAdjacentHTML('beforeend', loaderStyle);
    }
});
