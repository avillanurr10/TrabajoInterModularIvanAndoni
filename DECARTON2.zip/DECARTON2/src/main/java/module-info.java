module org.example.decarton2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.net.http;
    requires io.javalin;
    requires java.sql;


    opens org.example.decarton2 to javafx.fxml;
    exports org.example.decarton2;
}