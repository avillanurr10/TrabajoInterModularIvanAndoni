package org.example.decarton2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Cargar la vista de login desde el archivo FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
        Parent root = loader.load();

        // Configurar la escena
        Scene scene = new Scene(root, 300, 300);
        scene.getStylesheets().add(getClass().getResource("/styles/styles.css").toExternalForm());
        primaryStage.setTitle("Login Page");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        // Iniciar el servidor Javalin en un hilo separado
        Thread serverThread = new Thread(AppServer::startServer);
        serverThread.setDaemon(true);
        serverThread.start();

        // Iniciar la aplicación JavaFX
        launch(args);
    }
}