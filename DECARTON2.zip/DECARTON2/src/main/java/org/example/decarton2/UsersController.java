package org.example.decarton2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.eclipse.jetty.server.Authentication;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class UsersController {

    @FXML
    private TableView<User> usersTable;

    @FXML
    private TableColumn<User, String> usernameColumn;

    @FXML
    private TableColumn<Authentication.User, Button> actionsColumn;

    public void initialize() {
        // Configurar las columnas de la tabla
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        actionsColumn.setCellValueFactory(new PropertyValueFactory<>("deleteButton"));

        // Cargar la lista de usuarios desde el backend
        loadUsers();
    }

    private void loadUsers() {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:7000/users"))
                .GET()
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                String[] usernames = response.body().split(",");
                ObservableList<User> users = FXCollections.observableArrayList();

                for (String username : usernames) {
                    User user = new User(username.trim());
                    user.setDeleteButton(createDeleteButton(user));
                    users.add(user);
                }

                usersTable.setItems(users);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Button createDeleteButton(User user) {
        Button deleteButton = new Button("Delete");
        deleteButton.getStyleClass().add("delete-button");

        deleteButton.setOnAction(event -> {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("http://localhost:7000/delete?username=" + user.getUsername()))
                    .DELETE()
                    .build();

            try {
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() == 200) {
                    usersTable.getItems().remove(user);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        return deleteButton;
    }

    @FXML
    private void goBackToLogin() {
        Stage stage = (Stage) usersTable.getScene().getWindow();
        stage.close();
    }
}