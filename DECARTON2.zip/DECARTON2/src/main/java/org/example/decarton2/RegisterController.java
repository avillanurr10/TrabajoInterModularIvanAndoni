package org.example.decarton2;


import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class RegisterController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label messageLabel;

    @FXML
    private void handleRegister() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        // Enviar solicitud POST al servidor Javalin
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:7000/register"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString("username=" + username + "&password=" + password))
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Mostrar mensaje según la respuesta del servidor
            if (response.statusCode() == 201) {
                messageLabel.setText("User registered successfully!");
                messageLabel.setStyle("-fx-text-fill: green;");
            } else if (response.statusCode() == 409) {
                messageLabel.setText("User already exists");
                messageLabel.setStyle("-fx-text-fill: red;");
            } else {
                messageLabel.setText("Error registering user");
                messageLabel.setStyle("-fx-text-fill: red;");
            }
        } catch (Exception e) {
            messageLabel.setText("Error connecting to server");
            messageLabel.setStyle("-fx-text-fill: red;");
        }
    }
}