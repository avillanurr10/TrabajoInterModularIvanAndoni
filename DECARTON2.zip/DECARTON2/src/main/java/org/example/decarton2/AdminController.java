package org.example.decarton2;


import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class AdminController {

    @FXML
    private TableView<User> usersTable;

    @FXML
    private TableColumn<User, String> usernameColumn;

    @FXML
    private TableColumn<User, HBox> actionsColumn; // Cambiado a HBox

    @FXML
    private TextField newUsernameField;

    @FXML
    private PasswordField newPasswordField;

    public void initialize() {
        // Configurar las columnas de la tabla
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));

        actionsColumn.setCellValueFactory(cellData -> {
            User user = cellData.getValue();
            HBox buttonsBox = new HBox(5); // Espacio entre botones
            buttonsBox.getChildren().addAll(user.getDeleteButton(), user.getChangePasswordButton());
            return new ReadOnlyObjectWrapper<>(buttonsBox);
        });

        // Cargar la lista de usuarios desde el backend
        loadUsers();
    }

    private void loadUsers() {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:7000/users"))
                .GET()
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                String[] usernames = response.body().split(",");
                ObservableList<User> users = FXCollections.observableArrayList();

                for (String username : usernames) {
                    User user = new User(username.trim());
                    user.setDeleteButton(createDeleteButton(user));
                    user.setChangePasswordButton(createChangePasswordButton(user));
                    users.add(user);
                }

                usersTable.setItems(users);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Button createDeleteButton(User user) {
        Button deleteButton = new Button("Delete");
        deleteButton.getStyleClass().add("delete-button");

        deleteButton.setOnAction(event -> {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("http://localhost:7000/delete?username=" + user.getUsername()))
                    .DELETE()
                    .build();

            try {
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() == 200) {
                    usersTable.getItems().remove(user);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        return deleteButton;
    }

    private Button createChangePasswordButton(User user) {
        Button changePasswordButton = new Button("Change Password");
        changePasswordButton.getStyleClass().add("button");

        changePasswordButton.setOnAction(event -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Change Password");
            dialog.setHeaderText("Enter new password for " + user.getUsername());
            dialog.setContentText("New Password:");

            dialog.showAndWait().ifPresent(newPassword -> {
                HttpClient client = HttpClient.newHttpClient();
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create("http://localhost:7000/change-password"))
                        .header("Content-Type", "application/x-www-form-urlencoded")
                        .POST(HttpRequest.BodyPublishers.ofString("username=" + user.getUsername() + "&newPassword=" + newPassword))
                        .build();

                try {
                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                    if (response.statusCode() == 200) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Success");
                        alert.setHeaderText(null);
                        alert.setContentText("Password changed successfully.");
                        alert.showAndWait();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        });

        return changePasswordButton;
    }

    @FXML
    private void createUser() {
        String username = newUsernameField.getText();
        String password = newPasswordField.getText();

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:7000/register"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString("username=" + username + "&password=" + password))
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 201) {
                loadUsers();
                newUsernameField.clear();
                newPasswordField.clear();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void logout() {
        Stage stage = (Stage) usersTable.getScene().getWindow();
        stage.close();
    }
}