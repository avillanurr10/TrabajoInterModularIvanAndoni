package org.example.decarton2;

import io.javalin.Javalin;

import java.util.HashMap;
import java.util.Map;

public class AppServer {
    private static final DatabaseManager dbManager = new DatabaseManager();

    public static void startServer() {
        dbManager.initializeDatabase();

        Javalin app = Javalin.create().start(7000);

        // Ruta para manejar el login
        app.post("/login", ctx -> {
            String username = ctx.formParam("username");
            String password = ctx.formParam("password");

            if (dbManager.validateUser(username, password)) {
                ctx.status(200).result("Login successful");
            } else {
                ctx.status(401).result("Invalid credentials");
            }
        });

        // Ruta para manejar el registro
        app.post("/register", ctx -> {
            String username = ctx.formParam("username");
            String password = ctx.formParam("password");

            if (dbManager.addUser(username, password)) {
                ctx.status(201).result("User registered successfully");
            } else {
                ctx.status(409).result("User already exists");
            }
        });

        // Ruta para eliminar usuarios
        app.delete("/delete", ctx -> {
            String username = ctx.queryParam("username");

            if (dbManager.deleteUser(username)) {
                ctx.status(200).result("User deleted successfully");
            } else {
                ctx.status(404).result("User not found");
            }
        });

        // Ruta para obtener todos los usuarios
        app.get("/users", ctx -> {
            String[] users = dbManager.getAllUsers();
            ctx.result(String.join(",", users));
        });

        // Ruta para cambiar la contraseña de un usuario
        app.post("/change-password", ctx -> {
            String username = ctx.formParam("username");
            String newPassword = ctx.formParam("newPassword");

            if (dbManager.changePassword(username, newPassword)) {
                ctx.status(200).result("Password changed successfully");
            } else {
                ctx.status(404).result("User not found");
            }
        });
    }
}