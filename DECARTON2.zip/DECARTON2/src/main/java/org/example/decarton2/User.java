package org.example.decarton2;

import javafx.scene.control.Button;



import javafx.scene.control.Button;

public class User {
    private String username;
    private Button deleteButton;
    private Button changePasswordButton;

    public User(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public Button getDeleteButton() {
        return deleteButton;
    }

    public void setDeleteButton(Button deleteButton) {
        this.deleteButton = deleteButton;
    }

    public Button getChangePasswordButton() {
        return changePasswordButton;
    }

    public void setChangePasswordButton(Button changePasswordButton) {
        this.changePasswordButton = changePasswordButton;
    }
}