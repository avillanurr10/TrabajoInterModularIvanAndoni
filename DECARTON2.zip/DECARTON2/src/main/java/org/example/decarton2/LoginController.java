package org.example.decarton2;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label messageLabel;

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:7000/login"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString("username=" + username + "&password=" + password))
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                messageLabel.setText("Login successful!");
                messageLabel.setStyle("-fx-text-fill: green;");

                if ("admin".equals(username)) {
                    try {
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/admin.fxml"));
                        Parent root = loader.load();

                        Stage stage = new Stage();
                        stage.setTitle("Admin Panel");
                        stage.setScene(new Scene(root, 600, 400));
                        stage.show();
                    } catch (Exception e) {
                        e.printStackTrace(); // Imprime el error completo
                        messageLabel.setText("Error loading admin panel");
                        messageLabel.setStyle("-fx-text-fill: red;");
                    }
                }
            } else {
                messageLabel.setText("Invalid credentials");
                messageLabel.setStyle("-fx-text-fill: red;");
            }
        } catch (Exception e) {
            e.printStackTrace();
            messageLabel.setText("Error connecting to server");
            messageLabel.setStyle("-fx-text-fill: red;");
        }
    }

    @FXML
    private void openRegisterPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/register.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Register Page");
            stage.setScene(new Scene(root, 300, 250));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}